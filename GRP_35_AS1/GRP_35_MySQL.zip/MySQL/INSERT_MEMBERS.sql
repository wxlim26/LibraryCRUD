#INSERT INTO MEMBERS
INSERT INTO Member VALUES ("A101A", "Hermione" , "Granger", "Science", 33336663, "flying@als.edu", 0);
INSERT INTO Member VALUES ("A201B","Sherlock", "Holmes", "Law", 44327676, "elementarydrw@als.edu", 0);
INSERT INTO Member VALUES ("A301C","Tintin", NULL, "Engineering", 14358788, "luvmilu@als.edu", 0);
INSERT INTO Member VALUES ("A401D","Prinche", "Hamlet","FASS", 16091609, "tobeornot@als.edu", 0);
INSERT INTO Member VALUES ("A5101E","Willy", "Wonka","FASS", 19701970, "choco1@als.edu", 0);
INSERT INTO Member VALUES ("A601F","Holly", "Golightly", "Business", 55548008, "diamond@als.edu", 0);
INSERT INTO Member VALUES ("A701G","Raskolnikov", NULL, "Law" ,18661866, "oneaxe@als.edu", 0);
INSERT INTO Member VALUES ("A801H","Patrick", "Bateman", "Business",38548544, "mice@als.edu", 0);
INSERT INTO Member VALUES ("A901I","Captain", "Ahab", "Science", 18511851, "wwhale@als.edu", 0);